package com.AdvanceTraining;
public abstract class Instrument {
	public abstract void play();
}
